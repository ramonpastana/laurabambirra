<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Entrar extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->helper('recaptchalib_helper');
        $this->load->model('registro_model');
    }

    public function index()
    {
        $data['title'] = 'Registro';
        $this->load->view('login',$data);

    }
    //función para verificar si el captcha es correcto
    function verifica_captcha()
    {
        //aquí debemos la clave privada que recaptcha nos ha dado
        $privatekey = "tu clave privada";
        $resp = recaptcha_check_answer ($privatekey,
            $_SERVER["REMOTE_ADDR"],
            $this->input->post("recaptcha_challenge_field"),
            $this->input->post("recaptcha_response_field"));

        if (!$resp->is_valid) {
            //si el captcha introducido es incorrecto se lo decimos
            $this->form_validation->set_message('verifica_captcha','El %s es incorrecto');
            return FALSE;
        } else {

        }
    }

    function nuevo_usuario()
    {
        if(isset($_POST['registro']) and $_POST['registro'] == 'si')
        {
            //tratamos los campos del formulario y comprobamos
            $this->form_validation->set_rules('nick', 'nick', 'required|trim|min_length[4]|max_length[20]|xss_clean');
            $this->form_validation->set_rules('password', 'password', 'required|trim|min_length[6]|xss_clean');

            //línea importante, llamamos la función que verifica el captcha con callback_verifica_captcha
            $this->form_validation->set_rules('recaptcha_response_field', 'codigo captcha','callback_verifica_captcha|xss_clean');

            //lanzamos mensajes de error si es que los hay
            $this->form_validation->set_message('required', 'El %s es requerido');
            $this->form_validation->set_message('min_length', 'El %s debe tener al menos %s car&aacute;cteres');
            $this->form_validation->set_message('max_length', 'El %s debe tener al menos %s car&aacute;cteres');

            if (!$this->form_validation->run())
            {
                $this->index();
            }
            else
            {
                $nick = $this->input->post('nick');
                $password = md5($this->input->post ('password'));
                $insertar = $this->registro_model->nuevo_usuario($nick,$password);
                redirect(base_url().'registro');
            }
        }
    }

    public function cadeado()
    {
        $this->load->view('sistema/cad_cad.php');

    }
}