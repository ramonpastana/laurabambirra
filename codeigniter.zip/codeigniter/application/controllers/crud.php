<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Crud extends CI_Controller{

	public function entra()
	{
		$alerta = null;

		if ($this->input->post('cadastro') === "cadastro")


	{
		echo "ok";

			}

		$this->load->view('welcome_message');



}}