<?php

class Sistema extends CI_Controller
{
    public function index()
    {
        $dados = array(
            'titulo_pagina' => 'Titulo da pagina',
            'view_principal' => 'home');
        $this->load->view('sistema/includes/cad_aluga', $dados);
    }
}