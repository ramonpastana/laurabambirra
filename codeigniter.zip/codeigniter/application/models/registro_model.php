
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Registro_model extends CI_Model
{
    public function construct()
    {
        parent::__construct();
    }
    //hacemos la inserción en la base de datos
    function nuevo_usuario($nick,$password)
    {
        //conseguimos su ip
        $ip = $_SERVER ['REMOTE_ADDR'];
        //establecemos la hora del país que nos interese
        date_default_timezone_set("Europe/Madrid");
        $fecha = date('Y-m-d H:i:s');
        //creamos un array con todos los datos
        $data = array(
            'nick' => $nick,
            'password' => $password,
            'fecha_registro' => $fecha,
            'ip' => $ip
        );
        //los introducimos en la base de datos y
        //devolvemos al controlador por si queremos
        //hacer algo más, en este caso sólo redireccionamos
        return $this->db->insert('usuarios', $data);
    }
}