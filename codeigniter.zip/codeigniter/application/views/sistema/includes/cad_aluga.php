<?php

$this->load->view('sistema/includes/'. $view_principal);
