<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Home extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('calendario_model');
	}

	private function _buildCalendar($year, $month, $totalMonths = 6)
	{
		$calData = array();

		//como vemos en genera calendario le pasamos el año y el mes para que sepa que debe mostrar
		for($i = 1; $i <= $totalMonths; $i++)
		{
			$data =  array('calendario' => $this->calendario_model->genera_calendario($year, $month));
			$calData[] = $this->load->view('cal', $data, TRUE);
			if($month == 12)
			{
				$year++;
				$month = 1;
			}
			else
			{
				$month++;
			}
		}
		return $calData;
	}

	public function cal($year = null, $month = null)
	{
		$this->_defaultYearMonth($year, $month);
		$cal = $this->_buildCalendar($year, $month, 10);
		$this->load->view("welcome_message", array("calendar" => $cal));
	}

	private function _defaultYearMonth($year, $month)
	{
		if(!$year)
		{
			$year = date('Y');
		}
		if(!$month)
		{
			$month = date('m');
		}
	}


}